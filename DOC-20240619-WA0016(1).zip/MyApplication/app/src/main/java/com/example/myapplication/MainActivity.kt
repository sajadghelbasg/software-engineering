package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val loginButton: Button = findViewById(R.id.loginButton)
        val guestLoginButton: Button = findViewById(R.id.guestLoginButton)

        loginButton.setOnClickListener {
            // کد مربوط به ورود معمولی
            val intent = Intent(this, InhabitantsActivity::class.java)
            startActivity(intent)
        }

        guestLoginButton.setOnClickListener {
            // کد مربوط به ورود مهمان
            val intent = Intent(this, DashboardActivity::class.java)
            startActivity(intent)
        }
    }
}
