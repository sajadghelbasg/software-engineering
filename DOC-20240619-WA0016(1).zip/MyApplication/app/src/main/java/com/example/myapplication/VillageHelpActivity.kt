package com.example.myapplication

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class VillageHelpActivity : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_village_help) // R.layout.activity_health باید به لایهٔ XML مربوط به این Activity اشاره کند

        // دکمه برگشت
        val backIcon: ImageView = findViewById(R.id.village_help_back_icon)
        backIcon.setOnClickListener {
            onBackPressed()
        }
    }

    // اگر نیاز به اضافه کردن متدهای دیگر برای مدیریت منطق خاص در این Activity دارید، می‌توانید آنها را اینجا اضافه کنید.

}
