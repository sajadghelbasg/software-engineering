package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NavUtils

class DashboardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        // لیست اخبار روستا (محدود به دو خبر)
        val newsList = listOf(
            "خبر 1: اینجا متن خبر اول است.",
            "خبر 2: اینجا متن خبر دوم است."
        )




        // لیست مکان‌های گردشگری
        val touristSpotsList = listOf(
            "مکان گردشگری 1: اینجا توضیحات مکان گردشگری اول است.",
            "مکان گردشگری 2: اینجا توضیحات مکان گردشگری دوم است."
        )


        // دکمه برای رفتن به صفحه اخبار
        val newsButton: Button = findViewById(R.id.news_button)
        newsButton.setOnClickListener {
            val intent = Intent(this, NewsActivity::class.java)
            startActivity(intent)
        }

        // دکمه برای رفتن به صفحه مکان‌های گردشگری
        val touristSpotsButton: Button = findViewById(R.id.tourist_spots_button)
        touristSpotsButton.setOnClickListener {
            val intent = Intent(this, TouristSpotsActivity::class.java)
            startActivity(intent)
        }

        // دکمه برگشت
        val backButton: Button = findViewById(R.id.back_button)
        backButton.setOnClickListener {
            NavUtils.navigateUpFromSameTask(this)
        }
    }
}
