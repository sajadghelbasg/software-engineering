package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class InhabitantsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inhabitants)

        val councilText = findViewById<TextView>(R.id.council_text)
        councilText.setOnClickListener {
            val intent = Intent(this, CouncilActivity::class.java)
            startActivity(intent)
        }

        val culturalSportsText = findViewById<TextView>(R.id.cultural_sports_text)
        culturalSportsText.setOnClickListener {
            val intent = Intent(this, CulturalSportsActivity::class.java)
            startActivity(intent)
        }

        val healthText = findViewById<TextView>(R.id.health_text)
        healthText.setOnClickListener {
            val intent = Intent(this, HealthActivity::class.java)
            startActivity(intent)
        }

        val villageHelpText = findViewById<TextView>(R.id.village_help_text)
        villageHelpText.setOnClickListener {
            val intent = Intent(this, VillageHelpActivity::class.java)
            startActivity(intent)
        }
    }
}
