package com.example.myapplication

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class NewsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_news)

        // لیست کامل اخبار روستا
        val fullNewsList = listOf(
            "خبر 1: اینجا متن خبر اول است.",
            "خبر 2: اینجا متن خبر دوم است.",
            "خبر 3: اینجا متن خبر سوم است.",
            "خبر 4: اینجا متن خبر چهارم است."
        )

        // پیدا کردن ListView در فایل XML برای اخبار
        val fullNewsListView: ListView = findViewById(R.id.full_news_list)

        // تنظیم آداپتر برای ListView اخبار
        val fullNewsAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, fullNewsList)
        fullNewsListView.adapter = fullNewsAdapter
    }
}
