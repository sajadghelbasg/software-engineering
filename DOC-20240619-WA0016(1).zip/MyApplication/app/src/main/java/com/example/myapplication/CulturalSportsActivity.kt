package com.example.myapplication

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class CulturalSportsActivity : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cultural_sports) // R.layout.activity_health باید به لایهٔ XML مربوط به این Activity اشاره کند

        // دکمه برگشت
        val backIcon: ImageView = findViewById(R.id.cultural_sports_back_icon)
        backIcon.setOnClickListener {
            onBackPressed()
        }
    }

    // اگر نیاز به اضافه کردن متدهای دیگر برای مدیریت منطق خاص در این Activity دارید، می‌توانید آنها را اینجا اضافه کنید.

}
