package com.example.myapplication

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class TouristSpotsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tourist_spots)

        // لیست کامل مکان‌های گردشگری
        val fullTouristSpotsList = listOf(
            "مکان گردشگری 1: اینجا توضیحات مکان گردشگری اول است.",
            "مکان گردشگری 2: اینجا توضیحات مکان گردشگری دوم است.",
            "مکان گردشگری 3: اینجا توضیحات مکان گردشگری سوم است.",
            "مکان گردشگری 4: اینجا توضیحات مکان گردشگری چهارم است."
        )
        }


 }
